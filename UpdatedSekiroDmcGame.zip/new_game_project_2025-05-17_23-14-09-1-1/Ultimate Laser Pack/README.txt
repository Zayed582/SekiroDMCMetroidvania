Hello! Thanks for purchasing and downloading the Ultimate Laser Pack. 
- Made by: Kanpelle

-------------------------------------------------------------------------------------------------------------

 >>> License - Ultimate Laser Pack

 ----------

 - You can modify the assets. 
 - You may use make your own sprites in this style or use them as reference for your own.
 - Making additional sprites in the same style or using them as reference for your own project is also allowed.
 
 ----------

 - You can use these assets in any kind of projects, including commercial projects.

 [ Except anything to do with NFTs or AI training is not allowed ]

 ----------

 - You can not redistribute the asset pack itself or resell it on other platforms, even if it is slightly modified.
 - You can redistribute your own projects made with these assets like games, software, or other.
 - Making your project opensource is also allowed.
 - For open source projects include a note that says some or all assets are made by Kanpelle together with the licensing terms.

 ----------

 - Credit is required : (Kanpelle) 

 - Credit example : Assets -From : Ultimate Laser Pack -By : Kanpelle.
 - If you share your game on itch.io a link to the Asset Packs page would be very appreciated.
 - But feel free to credit in whatever way fits your project best.

 ----------

 Thanks for reading, and I hope you have fun with your project!

-------------------------------------------------------------------------------------------------------------
 
 >>> Support 

 If you enjoy this asset pack consider leaving a rating and a comment. 
 It really helps to support the future of this project!

 ----------

 Check out my other stuff at Itch.io - https://kanpelle.itch.io/
